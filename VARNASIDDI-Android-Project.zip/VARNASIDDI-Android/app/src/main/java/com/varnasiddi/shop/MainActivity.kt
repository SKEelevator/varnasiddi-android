package com.varnasiddi.shop

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Pink = Color(0xFFE64980)
private val Purple = Color(0xFF713B8F)
private val PalePink = Color(0xFFFFF0F5)
private val Ink = Color(0xFF28202B)
private val Page = Color(0xFFFFFBFD)

data class Saree(val name: String, val type: String, val price: Int, val emoji: String)

private val catalogue = listOf(
    Saree("Royal Banarasi Silk", "Silk", 3499, "🌸"),
    Saree("Everyday Cotton Elegance", "Cotton", 899, "🌿"),
    Saree("Blush Designer Saree", "Designer", 2299, "🌷"),
    Saree("Traditional Kanjivaram", "Traditional", 4999, "✨"),
    Saree("Festive Zari Collection", "Festive", 2799, "🌺"),
    Saree("Lightweight Printed Saree", "Printed", 1299, "🌼")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VarnasiddiApp() } }
    }
}

@Composable
fun VarnasiddiApp() {
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    val cart = remember { mutableStateListOf<Saree>() }
    val wishlist = remember { mutableStateListOf<Saree>() }

    Scaffold(
        containerColor = Page,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Home", "Shop", "Wishlist", "Cart", "Profile").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Text(
                                when (item) {
                                    "Home" -> "⌂"
                                    "Shop" -> "◇"
                                    "Wishlist" -> "♡"
                                    "Cart" -> "🛍"
                                    else -> "♙"
                                },
                                fontSize = 21.sp
                            )
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Pink,
                            selectedTextColor = Pink,
                            indicatorColor = PalePink
                        )
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            "Home" -> HomeScreen(
                Modifier.padding(padding),
                onShop = { tab = "Shop" },
                onAdd = { cart.add(it) },
                query = query,
                onQuery = { query = it }
            )
            "Shop" -> ShopScreen(
                Modifier.padding(padding), query, onQuery = { query = it },
                category = category, onCategory = { category = it },
                onAdd = { cart.add(it) },
                onWishlist = { if (it in wishlist) wishlist.remove(it) else wishlist.add(it) },
                wishlist = wishlist
            )
            "Wishlist" -> ItemListScreen(
                Modifier.padding(padding), "Your Wishlist", wishlist,
                emptyMessage = "Your favourite sarees will appear here.",
                actionLabel = "Remove",
                onAction = { wishlist.remove(it) }
            )
            "Cart" -> CartScreen(Modifier.padding(padding), cart)
            else -> ProfileScreen(Modifier.padding(padding))
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    onShop: () -> Unit,
    onAdd: (Saree) -> Unit,
    query: String,
    onQuery: (String) -> Unit
) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Spacer(Modifier.height(20.dp))
            Text("VARNASIDDI", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Purple)
            Text("The beauty of Indian tradition", fontSize = 13.sp, color = Color.Gray)
            Spacer(Modifier.height(18.dp))
            SearchBox(query, onQuery)
            Spacer(Modifier.height(20.dp))
            Column(
                Modifier.fillMaxWidth().background(PalePink, RoundedCornerShape(24.dp)).padding(22.dp)
            ) {
                Text("THE NEW COLLECTION", color = Pink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("Elegance Woven\nInto Every Thread", fontSize = 28.sp, lineHeight = 34.sp, color = Purple, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Discover sarees for every beautiful occasion.", color = Ink, fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                Button(onClick = onShop, colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
                    Text("EXPLORE COLLECTION")
                }
            }
            Spacer(Modifier.height(24.dp))
            SectionTitle("Featured Sarees")
            Spacer(Modifier.height(12.dp))
        }
        items(catalogue.take(4)) { product ->
            ProductRow(product, onAdd = { onAdd(product) }, onWishlist = null, isWishlisted = false)
            Spacer(Modifier.height(10.dp))
        }
        item {
            Spacer(Modifier.height(8.dp))
            Text("Made for your moments. Woven for your memories.", modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center, color = Purple, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ShopScreen(
    modifier: Modifier, query: String, onQuery: (String) -> Unit,
    category: String, onCategory: (String) -> Unit,
    onAdd: (Saree) -> Unit, onWishlist: (Saree) -> Unit, wishlist: List<Saree>
) {
    val categories = listOf("All", "Silk", "Cotton", "Designer", "Traditional", "Festive", "Printed")
    val filtered = catalogue.filter {
        (category == "All" || it.type == category) &&
        (query.isBlank() || it.name.contains(query, true) || it.type.contains(query, true))
    }
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Spacer(Modifier.height(20.dp))
            SectionTitle("Shop Sarees")
            Spacer(Modifier.height(12.dp))
            SearchBox(query, onQuery)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.take(4).forEach { cat ->
                    FilterChip(selected = category == cat, onClick = { onCategory(cat) }, label = { Text(cat) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.drop(4).forEach { cat ->
                    FilterChip(selected = category == cat, onClick = { onCategory(cat) }, label = { Text(cat) })
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        if (filtered.isEmpty()) {
            item { Text("No sarees found. Try another search.", color = Color.Gray, modifier = Modifier.padding(16.dp)) }
        } else {
            items(filtered) { product ->
                ProductRow(product, onAdd = { onAdd(product) }, onWishlist = { onWishlist(product) }, isWishlisted = product in wishlist)
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun ProductRow(product: Saree, onAdd: () -> Unit, onWishlist: (() -> Unit)?, isWishlisted: Boolean) {
    Row(
        Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(94.dp).background(PalePink, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) { Text(product.emoji, fontSize = 38.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(product.name, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(product.type, color = Color.Gray, fontSize = 12.sp)
            Text("₹${product.price}", color = Purple, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onAdd,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Pink)
                ) { Text("Add to cart", fontSize = 11.sp) }
                if (onWishlist != null) {
                    Spacer(Modifier.width(6.dp))
                    Text(if (isWishlisted) "♥" else "♡", color = Pink, fontSize = 24.sp,
                        modifier = Modifier.clickable { onWishlist() }.padding(4.dp))
                }
            }
        }
    }
}

@Composable
private fun CartScreen(modifier: Modifier, cart: List<Saree>) {
    val total = cart.sumOf { it.price }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle("Your Cart")
        Spacer(Modifier.height(14.dp))
        if (cart.isEmpty()) {
            Text("Your cart is empty. Visit Shop to discover sarees.", color = Color.Gray)
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(cart) { ProductRow(it, onAdd = {}, onWishlist = null, isWishlisted = false) }
            }
            Spacer(Modifier.height(12.dp))
            Text("Total: ₹$total", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Purple)
            Spacer(Modifier.height(8.dp))
            Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
                Text("Continue to checkout")
            }
            Text("Demo only: checkout and payments are not connected yet.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ItemListScreen(
    modifier: Modifier, title: String, products: List<Saree>,
    emptyMessage: String, actionLabel: String, onAction: (Saree) -> Unit
) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle(title)
        Spacer(Modifier.height(14.dp))
        if (products.isEmpty()) Text(emptyMessage, color = Color.Gray)
        else LazyColumn { items(products) { product ->
            ProductRow(product, onAdd = { onAction(product) }, onWishlist = null, isWishlisted = false)
            Spacer(Modifier.height(8.dp))
        } }
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle("Your Profile")
        Spacer(Modifier.height(16.dp))
        Text("Welcome to VARNASIDDI", fontSize = 20.sp, color = Purple, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Sign-in options will be connected in a later setup step.", color = Color.Gray)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = {}) { Text("Mobile number / OTP") }
        OutlinedButton(onClick = {}) { Text("Continue with Google") }
        Spacer(Modifier.height(8.dp))
        Text("Demo interface: authentication is not connected yet.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun SearchBox(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Search sarees, colours and styles") },
        singleLine = true,
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
}
