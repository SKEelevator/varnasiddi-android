# VARNASIDDI Android

A starter native Android shopping app built with Kotlin and Jetpack Compose.

## Current demo features
- Home screen with brand banner
- Sample saree catalogue with demo prices
- Search and category filters
- Add-to-cart interaction
- Wishlist interaction
- Bottom navigation
- Placeholder profile screen

## Not yet connected
This is a starter/demo app, not a production-ready store. Firebase phone OTP and Google sign-in, backend inventory/order management, image uploads, voice search, payment gateway, and shipping integrations still require setup. Sample products/prices are placeholders and must be replaced with real data.

## Build an APK using GitHub Actions
1. Upload the contents of this project to the root of a GitHub repository (keep `.github/workflows/android.yml`).
2. Open the repository's **Actions** tab.
3. Select **Build VARNASIDDI Android APK**.
4. Tap **Run workflow** if it has not run automatically.
5. When the run succeeds, open the run, scroll to **Artifacts**, and download `varnasiddi-debug-apk`.
6. Extract the ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from that source.

The first build may take several minutes. A debug APK is for testing, not Play Store release.
